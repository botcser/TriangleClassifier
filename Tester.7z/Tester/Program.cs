﻿using System;

namespace Tester;

class Program
{
    private static void Main()
    {
        var row = 0;

        do
        {
            if (row is 0 or >= 25)
                ResetConsole();

            var input = Console.ReadLine();

            if (string.IsNullOrEmpty(input)) break;

            var input1 = float.Parse(input);

            input = Console.ReadLine();

            if (string.IsNullOrEmpty(input)) break;

            var input2 = float.Parse(input);

            input = Console.ReadLine();

            if (string.IsNullOrEmpty(input)) break;

            var input3 = float.Parse(input);

            TriangleClassifier.TriangleClassifier.ClassifyTriangle(input1, input2, input3);
            row += 4;
        } 
        while (true);

        return;
        
        void ResetConsole()
        {
            if (row > 0)
            {
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
            }

            Console.Clear();
            Console.WriteLine($"{Environment.NewLine}Press <Enter> only to exit; otherwise, enter a string and press <Enter>:{Environment.NewLine}");

            row = 3;
        }
    }
}